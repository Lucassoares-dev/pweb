#include <stdio.h>

void main(){
	
	int a[4][4],b[4][4],c[4][4],d,e;
	
	for(d=0;d<4;d++){
		for(e=0;e<4;e++){
			
		    printf("A[%d][%d] = ",d,e);
		    scanf("%d",&a[d][e]);
		    
		    printf("B[%d][%d] = ",d,e);
		    scanf("%d",&b[d][e]);
		    
		}
	}
	
	for(d=0;d<4;d++){
		for(e=0;e<4;e++){
			
		    if(a[d][e]>b[d][e]){
		    	
		    	c[d][e]=a[d][e];
		    	
			}
			else{
				
				c[d][e]=b[d][e];
				
			}
		    
		    printf("|%5d| ",c[d][e]);
		    
		}
		printf("\n");
	}
	
	
	
}
