#include <stdio.h>

int main(){
    
    int a[4][3],b,c;
    
    for(b=0;b<4;b++){
        for(c=0;c<3;c++){
            printf("a quantidade de produto %d no armazem %d\n",c+1,b+1);
            scanf("%d",&a[b][c]);
        }
    }
    
    printf("o segundo armazem contem %d itens\no terceiro armazem tem uma media de %d produtos\nno total existem %d itens 1",a[1][0]+a[1][1]+a[1][2],(a[2][0]+a[2][1]+a[2][2])/3,a[0][0]+a[1][0]+a[2][0]+a[3][0]);
    
    return 0;
}