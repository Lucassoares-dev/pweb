#include <stdio.h>

int main(){
    
    int a[7][7],b,c;
    
    for(b=0;b<7;b++){
        for(c=0;c<7;c++){
            
            printf("A[%d][%d] = ",b,c);
            scanf("%d",&a[b][c]);
            
        }
    }
    
    for(b=0;b<7;b++){
        for(c=0;c<7;c++){
            
            printf("%2d ",a[c][b]);
            
        }
        printf("\n\n");
    }
    
    return 0;
}