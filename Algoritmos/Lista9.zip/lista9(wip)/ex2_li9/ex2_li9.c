#include <stdio.h>

void main(){
	
	int a[5][5],b,c,d,ac=0,ab=0,aa=0,bb=0;
	
	for(b=0;b<5;b++){
		for(c=0;c<5;c++){
			
			printf("A[%d][%d] = ",b,c);
			scanf("%d",&a[b][c]);
			
			if(b!=0 && c==b){
				
				ac+=a[b-1][c];
				
				for(d=0;d<c;d++){
					
					aa+=a[d][c];
					
				}
			}
			
			if(c!=0 && c==b){
				
				ab+=a[b][c-1];
				
			}
		}
	}
	
	for(b=0;b<5;b++){
		
		c=b;
		
		for(d=b+1;d<5;d++){
			
			bb+=a[d][c];
			
		}
		
	}
	
	for(b=0;b<5;b++){
		for(c=0;c<5;c++){
			
			printf("|%4d| ",a[b][c]);
			
			
		}
		printf("\n");
	}
	
	printf("a soma dos logo acima: %d\na soma dos logo abaixo: %d\na soma de todos acima: %d\na soma de todos abaixo: %d\n",ac,ab,aa,bb);
	
}
