#include <stdio.h>

int main(){
    
    float a[4][5],n;
    
    short b,c,t=0;
    
    for(b=0;b<4;b++){
        for(c=0;c<5;c++){
            
            printf("A[%d][%d] = ",b,c);
            scanf("%f",&a[b][c]);
        }
    }
    
    printf("qual o numero a ser procurado?\n");
    scanf("%f",&n);
    
    for(b=0;b<4;b++){
        for(c=0;c<5;c++){
            
            if(n==a[b][c]){
                
                printf("o numero foi encontrado em (%d,%d)\n",b,c);
                t++;
                
            }
            
            if(t==0 && b==3 && c==4){
                
                printf("o numero nao foi encontrado");
                
            }
            
        }
    }
    
    return 0;
}
