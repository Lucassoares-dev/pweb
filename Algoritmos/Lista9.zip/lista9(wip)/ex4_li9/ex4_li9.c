#include <stdio.h>

int main(){
    
    int a[3][3],b,c,m=0,p=0,n=0;
    
    for(b=0;b<3;b++){
        for(c=0;c<3;c++){
            
            printf("A[%d][%d] = ",b,c);
            scanf("%d",&a[b][c]);
            
            m+=a[b][c];
            
            if(a[b][c]>=0){
                
                p+=a[b][c];
                n++;
 
            }
        }
    }
    
	printf("a media dos numeros da matriz foi %d\n",m/9);
    
    if(n==0){
    	
    	printf("a media dos positivos n/a\n9 foram negativos");
    	
	}
	else{
		
    printf("a media dos positivos %d\n%d foram negativos",p/n,9-n);
    
	}
    
    return 0;
}
