#include <stdio.h>
#define max 10

int main(){
    
    char a[3][max],r[max];
    int b,c,al[3];
    
    for(b=0;b<max;b++){
    	
        printf("digite a resposta da questao %d : ",b+1);
    	
        do{
        	
        scanf("%c",&r[b]);
        
        }while(r[b]<65 || r[b]>68 && r[b]<97 || r[b]>100);
        
        if(b<3){
        	
        al[b]=0;
        
        }
        
    }
    
    for(b=0;b<3;b++){
        for(c=0;c<max;c++){
            
            printf("digite a resposta da questao %d do aluno %d : ",c+1,b+1);
            do{
            	
            scanf("%c",&a[b][c]);
            
			}while(a[b][c]<65 || a[b][c]>68 && a[b][c]<97 || a[b][c]>100);
            
            if(a[b][c]==r[c] || a[b][c]==r[c]+32 || a[b][c]==r[c]-32){
                al[b]++;
            }
                     
        }
    }
    
    for(b=0;b<3;b++){
        printf("o aluno %d tem nota %d\n",b+1,al[b]);
    }
    
    return 0;
}
