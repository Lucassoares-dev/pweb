#include <stdio.h>

void main(){
	
	int ll,lc;
	
	printf("digite o numero de linhas da matriz\n");
	scanf("%d",&ll);
	
	printf("digite o numero de colunas da matriz\n");
	scanf("%d",&lc);
	
	int a[ll][lc],b[lc],c,d;
	
	for(d=0;d<lc;d++){
		
		b[d]=0;
		
	}
	
	for(c=0;c<ll;c++){
		for(d=0;d<lc;d++){
			
			printf("A[%d][%d] = ",c,d);
			scanf("%d",&a[c][d]);
			
			b[d]+=a[c][d];
			
		}
	}
	
	for(c=0;c<ll;c++){
		for(d=0;d<lc;d++){
			
			printf("|%4d| ",a[c][d]);
			
		}
		printf("\n\n");
	}
	
	for(d=0;d<lc;d++){
		printf(" %4d  ",b[d]);
	}	
}
