#include <stdio.h>

int main(){
    
    int a[3][4],b,c,d=0;
    
    for(b=0;b<3;b++){
        for(c=0;c<4;c++){
            scanf("%d",&a[b][c]);
            d+=a[b][c];
        }
    }
    printf("a soma dos elementos e %d",d);
    
    return 0;
}