#include <stdio.h>

int main(){
    
    int a[3][3],b[3][3],c,d;
    
    for(c=0;c<3;c++){
        for(d=0;d<3;d++){
            scanf("%d",&a[c][d]);
        }
    }
    
    for(c=0;c<3;c++){
        for(d=0;d<3;d++){
            b[c][d]=a[c][d]*2;
            printf("%d ",b[c][d]);
        }
        printf("\n");
    }
    
    return 0;
}