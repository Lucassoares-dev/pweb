#include <stdio.h>

int main(){
    
    int a[5][3],b,c,d;
    
    for(b=0;b<5;b++){
        for(c=0;c<3;c++){
            scanf("%d",&a[b][c]);
            if(b==0 && c==0){
                d=a[0][0];
            }
            if(a[b][c]>d){
                d=a[b][c];
            }
        }
    }
    printf("o maior elemento foi %d",d);
    
    return 0;
}