#include <stdio.h>

int main(){
    
    int a[4][4],b,c;
    
    for(b=0;b<4;b++){
        for(c=0;c<4;c++){
            scanf("%d",&a[b][c]);
        }
    }
    
    c=0;
    
    for(b=0;b<4;b++){
        printf("%d ",a[b][c]);
        c++;
    }
    
    return 0;
}