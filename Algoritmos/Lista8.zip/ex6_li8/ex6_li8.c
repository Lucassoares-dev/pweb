#include <stdio.h>

int main(){
    
    int a[3][4],b,c,d=0;
    
    for(b=0;b<3;b++){
        for(c=0;c<4;c++){
            scanf("%d",&a[b][c]);
        }
    }
    
    do{
        printf("linha a ser somada [1~3]");
        scanf("%d",&b);
    }while(b<1 && b>3);
    
    for(c=0;c<4;c++){
        d+=a[b-1][c];
    }
    
    printf("soma da linha %d: %d",b,d);
    
    return 0;
}