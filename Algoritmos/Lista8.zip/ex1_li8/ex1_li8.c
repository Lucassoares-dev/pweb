#include <stdio.h>

int main(){
    
    int a[4][3],b,c;
    
    for(b=0;b<4;b++){
        for(c=0;c<3;c++){
            scanf("%d",&a[b][c]);
        }
    }
    for(b=0;b<4;b++){
        for(c=0;c<3;c++){
            printf("%d ",a[b][c]);
        }
        printf("\n");
    }
    
    return 0;
}