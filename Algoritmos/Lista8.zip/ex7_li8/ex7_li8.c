#include <stdio.h>

int main(){
    
    int a[4][4],b,c,mn,pm;
    
    for(b=0;b<4;b++){
        for(c=0;c<4;c++){
            scanf("%d",&a[b][c]);
            if(b==0 && c==0){
                mn=a[0][0];
                pm=0;
            }
            if(mn<a[b][c]){
                mn=a[b][c];
                pm=b;
            }
        }
    }
    
    b=pm;
    
    for(c=0;c<4;c++){
        if(a[b][c]<mn){
            mn=a[b][c];
            pm=c;
        }
    }
    
    printf("o valor minimax da matriz e %d e esta na linha %d coluna %d",mn,b,pm);
    
    return 0;
}