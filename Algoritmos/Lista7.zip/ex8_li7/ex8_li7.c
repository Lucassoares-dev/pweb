#include <stdio.h>

int main(){
    
    int a[10]={1,2,3,4,5,6,7,8,9,0},b,c[10];
    
    for(b=0;b<10;b++){
        c[9-b]=a[b];
    }
    
    return 0;
}