#include <stdio.h>

int main(){
    int a[2][5],b,c;
    
    for(b=0;b<2;b++){
        for(c=0;c<5;c++){
            scanf("%d",&a[b][c]);
        }
    }
    
    for(b=0;b<2;b++){
        for(c=0;c<5;c++){
            if(a[b][c]<0){
            printf("%d ",a[b][c]);
            }
            else{
                printf("X ");
            }
        }
        printf("\n");
    }
    return 0;
}