#include <stdio.h>

int main(){
    int a[2][5],b,c,d=0;
    
    for(b=0;b<2;b++){
        for(c=0;c<5;c++){
            scanf("%d",&a[b][c]);
            if(a[b][c]>0){
                d++;
            }
        }
    }
        printf("%d numeros positivos",d);
    
    return 0;
}