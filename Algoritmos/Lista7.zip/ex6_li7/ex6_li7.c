#include <stdio.h>

int main(){
    int a[51],b,c=0;
    
    for(b=0;b<=100;b+=2){
        a[c]=b;
        printf("%d\n",a[c]);
        c++;
    }
    return 0;
}