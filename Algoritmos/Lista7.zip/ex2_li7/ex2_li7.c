#include <stdio.h>

int main(){
    int a[2][5],b,c;
    
    for(b=0;b<2;b++){
        for(c=0;c<5;c++){
            scanf("%d",&a[b][c]);
        }
    }
    
    for(b=1;b>=0;b--){
        for(c=4;c>=0;c--){
            printf("%d ",a[b][c]);
        }
        printf("\n");
    }
    return 0;
}